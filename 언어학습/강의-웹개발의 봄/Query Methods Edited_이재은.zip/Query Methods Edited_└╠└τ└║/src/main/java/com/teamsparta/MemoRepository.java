package com.teamsparta;

import com.teamsparta.entity.Memo;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MemoRepository extends JpaRepository<Memo, Long> {

    // 데이터베이스에서 모든 메모를 조회하고, modifiedAt 속성을 기준으로 내림차순으로 정렬하여 반환하는 메서드를 완성하세요.
    // memo 객체를 리스트로 반환하도록 작성해 주세요.
    // 데이터베이스에서 메모의 내용 중에서 주어진 키워드를 포함하는 메모를 조회하고,
    // modifiedAt 속성을 기준으로 내림차순으로 정렬하여 반환하는 메서드를 완성하세요.
    // memo 객체를 리스트로 반환하도록 작성해 주세요.

    List<Memo> findAllByOrderByModifiedAtDesc();
    List<Memo> findByContentsContainingOrderByModifiedAtDesc(String keyword);

}