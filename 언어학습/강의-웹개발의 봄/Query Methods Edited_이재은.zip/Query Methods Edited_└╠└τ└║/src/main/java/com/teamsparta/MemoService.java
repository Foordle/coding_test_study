package com.teamsparta;

import com.teamsparta.dto.MemoRequestDto;
import com.teamsparta.dto.MemoResponseDto;
import com.teamsparta.entity.Memo;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class MemoService {

    private final MemoRepository memoRepository;

    public MemoService(MemoRepository memoRepository) {
        this.memoRepository = memoRepository;
    }

    public MemoResponseDto createMemo(MemoRequestDto requestDto) {
        // RequestDto -> Entity
        Memo memo = new Memo(requestDto);

        // DB 저장
        Memo saveMemo = memoRepository.save(memo);

        // Entity -> ResponseDto
        MemoResponseDto memoResponseDto = new MemoResponseDto(saveMemo);

        return memoResponseDto;
    }

    public List<MemoResponseDto> getMemos() {

        // DB 조회
        // modifiedAt 속성을 기준으로 내림차순으로 정렬하는 메서드를 호출하여,
        // 각 메모를 MemoResponseDto 클래스의 객체로 변환하고 이를 스트림으로 처리한 뒤 리스트로 반환하는 코드를 완성하세요.
        return memoRepository.findAllByOrderByModifiedAtDesc().stream()
                .map(MemoResponseDto::new)
                .collect(Collectors.toList());
    }

    public List<MemoResponseDto> getMemosByKeyword(String keyword) {

        // DB 조회
        // 메모 내용에 특정 키워드를 포함하는 메모와 modifiedAt 속성을 기준으로 내림차순으로 정렬하는 메서드를 호출하여,
        // 각 메모를 MemoResponseDto 클래스의 객체로 변환하고 이를 스트림으로 처리한 뒤 리스트로 반환하는 코드를 완성하세요.
        return memoRepository.findByContentsContainingOrderByModifiedAtDesc(keyword).stream()
                .map(MemoResponseDto::new)
                .collect(Collectors.toList());
    }

    @Transactional
    public Long updateMemo(Long id, MemoRequestDto requestDto) {
        // 해당 메모가 DB에 존재하는지 확인
        Memo memo = findMemo(id);

        // memo 내용 수정
        memo.update(requestDto);

        return id;
    }

    public Long deleteMemo(Long id) {
        // 해당 메모가 DB에 존재하는지 확인
        Memo memo = findMemo(id);

        // memo 삭제
        memoRepository.delete(memo);

        return id;
    }

    private Memo findMemo(Long id) {
        return memoRepository.findById(id).orElseThrow(() ->
                new IllegalArgumentException("선택한 메모는 존재하지 않습니다.")
        );
    }
}