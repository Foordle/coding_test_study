CREATE TABLE memo
(
    id       BIGINT PRIMARY KEY,
    username VARCHAR(255),
    contents TEXT
);
